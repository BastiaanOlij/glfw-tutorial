# glfw-tutorial
Files for my little GLFW-tutorial series

Introduction
====
I'll write some sensible stuff here later but these are files related to a tutorial series on GLFW and related topics that I'm currently working on.
Note that these files will progress as the tutorial progresses. 
In the archive folder I'm placing zip files containing the source code as is after each tutorial.

Dependencies
====
This work is dependend on a number of other bits of source code.

First and foremost: http://www.glfw.org
GLFW is the cross platform framework we're using here. For convenience I've included the main header and compiled binaries in this repository but obviously I recommend you download the most recent source and compile it.

More will be added soon....

Links to articles
====
http://bastiaanolij.blogspot.com.au/p/glfw-tutorials.html
