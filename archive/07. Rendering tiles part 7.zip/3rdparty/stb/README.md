This folder contains those files from STB that I use in this project.
STB are Sean T Barrett's initials and these files are part of his wonderful public domain project from his github site here: https://github.com/nothings/stb
They are a collection of light weight, drop in source files for various graphic routines, anything from loading images, to scaling, to rendering fonts, noise functions, etc. 

Again as always I recommend checking out the original source as there may be improvements over the version I've included here.
