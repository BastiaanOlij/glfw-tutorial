#version 330

in vec4 color;
out vec4 fragcolor;

void main() {
  fragcolor = color;
}