This folder contains a library called fontstash created by Mikko Mononen, including my version of the glfontstash.h implementation for OpenGL 3.
It also includes STBs truetype library ontop of which fontstash was build, it just compiles easier that way.

Fontstash is a really neat little library for rendering truetype fonts through the use of textures. 
You can find the original source code here: https://github.com/memononen/fontstash
Or check out my fork that includes the OpenGL 3 additions: https://github.com/BastiaanOlij/fontstash

Again as always I recommend checking out the original source as there may be improvements over the version I've included here.
