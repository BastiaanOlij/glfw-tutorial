This folder contains compiled binaries for GLFW and the main header file that allows us to include GLFW into our project.
I didn't want to include the entire source code for GLFW into this repository but also didn't want to leave it up to someone trying this out to figure out how to compile everything.
I'm probably bending the official rules a little but hopefully I'm forgiven as I'm only trying to help people out getting into using GLFW.

libglfw3_mac.a is a universal binary (32 and 64bit) of GFLW 3.1
glfw3.lib is a 32bit compiled library compatible with VC 2010

Note that you should head down to www.glfw.org and either download the full source and/or official binaries so you are sure to be on the latest and correct version and have access to the source.

Disclaimer:
I am in no way associated to those who created GLFW. Use these compiled binaries at your own risk.